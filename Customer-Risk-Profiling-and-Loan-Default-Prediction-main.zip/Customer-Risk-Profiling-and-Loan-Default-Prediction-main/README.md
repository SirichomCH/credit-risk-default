# Customer-Risk-Profiling-and-Loan-Default-Prediction
Case study for a major financial institution.

Work includes estimation of lifetime loss curve for total eligible loans, a balance paydown curve, customer segmentation, customer risk profiling 
and the development of two classifiers to predict loan defaults.

The analysis was based on data that belong to the organization, thus cannot make them public.
